/*!
 * Carbon Copy — invisible authorship marks for text documents.
 * Works in the browser (window.Carbon) and in Node (module.exports).
 * MIT licensed.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Carbon = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // Four zero-width characters used as base-4 digits. All render as nothing.
  var DIGITS = ["\u200B", "\u200C", "\u200D", "\u2060"];
  // Invisible sentinels that bracket each mark.
  var START = "\u2061";
  var END = "\u2062";
  // Field separator inside the payload, and a magic prefix used as a checksum.
  var SEP = "\u001F";
  var MAGIC = "CBN1";

  var DIGIT_RE = /[\u200B\u200C\u200D\u2060]/;
  var MARK_RE = /\u2061([\u200B\u200C\u200D\u2060]*)\u2062/g;
  var ORPHAN_RE = /[\u200B\u200C\u200D\u2060]{8,}/g;
  var ALL_MARKS_RE = /\u2061[\u200B\u200C\u200D\u2060]*\u2062/g;

  /** Encode an arbitrary string as one bracketed zero-width mark. */
  function encode(str) {
    var bytes = new TextEncoder().encode(str);
    var out = START;
    for (var i = 0; i < bytes.length; i++) {
      var b = bytes[i];
      out += DIGITS[(b >> 6) & 3] + DIGITS[(b >> 4) & 3] +
             DIGITS[(b >> 2) & 3] + DIGITS[b & 3];
    }
    return out + END;
  }

  /**
   * Decode a run of zero-width digits back to a string.
   * Returns null unless the result is valid UTF-8 beginning with MAGIC,
   * which keeps stray invisible characters from producing false positives.
   */
  function decode(seq) {
    var chars = Array.prototype.filter.call(seq, function (c) {
      return DIGIT_RE.test(c);
    });
    if (!chars.length || chars.length % 4 !== 0) return null;

    var bytes = [];
    for (var i = 0; i < chars.length; i += 4) {
      bytes.push(
        (DIGITS.indexOf(chars[i]) << 6) | (DIGITS.indexOf(chars[i + 1]) << 4) |
        (DIGITS.indexOf(chars[i + 2]) << 2) | DIGITS.indexOf(chars[i + 3])
      );
    }
    try {
      var s = new TextDecoder("utf-8", { fatal: true }).decode(new Uint8Array(bytes));
      return s.indexOf(MAGIC) === 0 ? s : null;
    } catch (e) {
      return null;
    }
  }

  /** Build the payload string for one recipient's copy. */
  function payload(fields) {
    return [
      MAGIC,
      fields.author || "",
      fields.recipient || "",
      fields.issued || new Date().toISOString(),
      fields.id || Math.random().toString(36).slice(2, 8)
    ].join(SEP);
  }

  /**
   * Weave a mark through `text`, repeating it every `every` words so that a
   * partial copy still identifies itself.
   */
  function embed(text, fields, every) {
    every = every || 40;
    var mark = encode(typeof fields === "string" ? fields : payload(fields));
    var parts = text.split(/(\s+)/);
    var out = mark;
    var words = 0;
    for (var i = 0; i < parts.length; i++) {
      out += parts[i];
      if (parts[i] && !/^\s+$/.test(parts[i])) {
        words++;
        if (words % every === 0) out += mark;
      }
    }
    return out + mark;
  }

  /**
   * Recover every intact mark from a suspect text.
   * Falls back to hunting orphaned digit runs when the sentinels were stripped.
   */
  function extract(text) {
    var hits = [], m;
    MARK_RE.lastIndex = 0;
    while ((m = MARK_RE.exec(text)) !== null) {
      var p = decode(m[1]);
      if (p) hits.push(p);
    }
    if (!hits.length) {
      var runs = text.match(ORPHAN_RE) || [];
      for (var i = 0; i < runs.length; i++) {
        var p2 = decode(runs[i]);
        if (p2) hits.push(p2);
      }
    }
    return hits;
  }

  /** Parse a payload string into named fields. */
  function parse(p) {
    var f = String(p).split(SEP);
    return { author: f[1] || "", recipient: f[2] || "", issued: f[3] || "", id: f[4] || "" };
  }

  /**
   * Summarise what a suspect text reveals: who wrote it, who held the copy,
   * and whether several different copies were spliced together.
   */
  function inspect(text) {
    var hits = extract(text);
    if (!hits.length) return { found: false, marks: 0, copies: [] };
    var seen = {}, copies = [];
    hits.forEach(function (h) {
      if (!seen[h]) { seen[h] = 1; copies.push(parse(h)); }
    });
    return {
      found: true,
      marks: hits.length,
      copies: copies,
      spliced: copies.length > 1,
      author: copies[0].author,
      recipient: copies[0].recipient,
      issued: copies[0].issued,
      id: copies[0].id
    };
  }

  /** Remove every mark, returning the clean original text. */
  function strip(text) {
    return text.replace(ALL_MARKS_RE, "").replace(new RegExp(DIGIT_RE.source, "g"), "");
  }

  /** Replace marks with a visible glyph, for previewing where they sit. */
  function reveal(text, glyph) {
    return text.replace(ALL_MARKS_RE, glyph || "\u25C6");
  }

  return {
    encode: encode,
    decode: decode,
    payload: payload,
    embed: embed,
    extract: extract,
    parse: parse,
    inspect: inspect,
    strip: strip,
    reveal: reveal,
    DIGITS: DIGITS,
    START: START,
    END: END
  };
});
